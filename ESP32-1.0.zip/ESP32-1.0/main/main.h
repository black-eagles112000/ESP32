//
// Created by cyber on 17.07.21.
//

#ifndef DB_ESP32_MAIN_H
#define DB_ESP32_MAIN_H

void write_settings_to_nvs();

#endif //DB_ESP32_MAIN_H
